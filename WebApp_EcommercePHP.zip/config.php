<?php

define('BASEURL', $_SERVER['DOCUMENT_ROOT'].'/EcommerceShipping/');
define('CART_COOKIE','DJ0klaqhjkllm');
define('CART_COOKIE_EXPIRE', time() + (86400 *30));
define('TAXRATE', 0.087);

define('CURRENCY', 'usd');
define('CHEKCKOUTMODE', 'TEST');

if (CHEKCKOUTMODE == 'TEST') {
	define('STRIPE_PRIVATE', 'sk_test_emBK4Nm1ENPAZFMGttlXevO1');
	define('STRIPE_PUBLIC', 'pk_test_faQWYfK6xrnt9n57mPyQMqP0');
}