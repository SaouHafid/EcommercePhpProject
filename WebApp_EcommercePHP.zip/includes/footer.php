</div>
<br>
<br>
<div class="col-md-12 text-center">
&copy; Copyright 2017 Workinc Ecommerce
</div>

	<script>
	jQuery(window).scroll(function(){
		var vscroll = jQuery(this).scrollTop();
		jQuery('#logotext').css({
			"transform" : "translate(0px, "+vscroll/2+"px)"
		});

		var vscroll = jQuery(this).scrollTop();
		jQuery('#back-flower').css({
			"transform" : "translate("+vscroll/5+"px, -"+vscroll/12+"px)"
		});

		var vscroll = jQuery(this).scrollTop();
		jQuery('#fore-flower').css({
			"transform" : "translate(0px, -"+vscroll/2+"px)" 
		});
	});

	function detailsmodal(id){
		var data = {"id" : id};
		jQuery.ajax({
			url : '/EcommerceShipping/includes/details.php',
			method : "post",
			data : data,
			success: function(data){
				jQuery('body').append(data);
				jQuery('#details-modal').modal('toggle');
			}, 
			error: function(){
				alert("Il y a une erreur!");
			} 
		});
	}
	
	function update_cart(mode,edit_id,edit_size){
		var data = {"mode" : mode, "edit_id" : edit_id, "edit_size" : edit_size};
		jQuery.ajax({
			url : '/EcommerceShipping/admin/parsers/update_cart.php',
			method : "post",
			data : data,
			success : function(){location.reload();},
			error : function(){alert("Echec! Il y a une erreur.");},
		});
	}

	function ajouter_au_panier(){
	jQuery('#modal_errors').html("");
	var size = jQuery('#size').val();
	var quantity = jQuery('#quantity').val();
	var available = jQuery('#available').val();
	var error = '';
	var data = jQuery('#add-produit-form').serialize();
	if (size == '' || quantity == '' || quantity == 0){
		error += '<p class="text-danger text-center">Vous devez saisir la quantité et choisir la taille.</p>';
		jQuery('#modal_errors').html(error);
		return; 
	}else if(quantity > available){
		error += '<p class="text-danger text-center">Il y a seulement '+available+' disponible(s).</p>';
		jQuery('#modal_errors').html(error); 
		return;
	}else{
		jQuery.ajax({
			url: '/EcommerceShipping/admin/parsers/ajouter_panier.php',
			method: 'post',
			data: data,
			success: function(){
				location.reload();
			},
			error: function(){alert("Echec! Il y a une erreur.");}
		});
	}
}		
	</script>
</body>
</html>