<!-- left side bar -->
		<div class="col-md-2">
			Left side bar ! 
		</div>