<?php
	require_once '../core/init.php';
	$id = $_POST['id'];
	$id = (int)$id;
	$sql = "SELECT * FROM produits WHERE id = '$id'";
	$result = $db->query($sql);
	$produit = mysqli_fetch_assoc($result);
	$marque_id = $produit['marque'];
	$sql = "SELECT marque FROM marque WHERE id = '$marque_id'";
	$marque_result = $db->query($sql);
	$marque = mysqli_fetch_assoc($marque_result); 
	$taillestring = $produit['tailles'];
	$taillestring = rtrim($taillestring,',');
	$taille_array = explode(',', $taillestring);
?>	

	<!-- Details sur le modele -->
	<?php ob_start(); ?>
	<div class="modal fade details-1" id="details-modal" tabindex="-1" role="dialog" aria-labelledby="details-1" aria-hidden="true">
		<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header">
				<button class="close" type="button" onclick="closeModal()" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
				<h4 class="modal-title text-center"><?= $produit['titre']; ?></h4>
				<!--<?php //var_dump($taille_array); ?> -->
			</div>
			<div class="modal-body">
				<div class="container-fluid">
					<div class="row">
						<span id="modal_errors" class="bg-danger"></span>
						<div class="col-sm-6">
							<div class="center-block">
							<img src="<?= $produit['image']; ?>" alt="<?= $produit['titre']; ?>" class="details img-responsive">
							</div>
						</div>
						<div class="col-sm-6">
							<h4>Details</h4>
							<p><?= nl2br($produit['description']); ?></p>
							<hr>
							<p>Prix: $<?= $produit['prix']; ?></p>	
							<p>Marque: <?= $marque['marque'] ?></p> 
							<form action="add_cart.php" method="post" id="add-produit-form">
								<input type="hidden" name="produit_id" value="<?=$id;?>">
								<input type="hidden" name="available" id="available" value="">
								<div class="form-group">
									<div class="col-xs-3">
										<label for="quantity">Quantité:</label>
										<input type="number" class="form-control" id="quantity" name="quantity" min="0">
									</div>
									<!-- <div ></div> 
									<p>Available: 3</p>
								</div>  -->
								<br>
								<div class="col-xs-9">&nbsp;</div>
							</div>
								<br>
								<br> 
								<div class="form-group">
									<label for="size">Taille :</label>
									<select name="size" id="size" class="form-control">
										<option value=""></option>
										<?php foreach ($taille_array as $chaine) {
											$string_array = explode(':', $chaine);
											$taille = $string_array[0];
											$available = $string_array[1];
											echo '<option value="'.$taille.'" data-available="'.$available.'">'.$taille.'('.$available.' disponible)</option>';
										} 
										?>
										
									</select>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>

			<div class="modal-footer">
				<button class="btn btn-default" onclick="closeModal()">Fermer</button>
				<button class="btn btn-warning" onclick="ajouter_au_panier();return false;">
					<span class="glyphicon glyphicon-shopping-cart"></span>Ajouter au panier</button>
			</div>
			</div>
		</div>
	</div>   

	<script>
		jQuery('#size').change(function(){
			var available = jQuery('#size option:selected').data("available");
			jQuery('#available').val(available);
		});

		function closeModal(){
			jQuery('details-modal').modal('hide');
			setTimeout(function(){
				jQuery('#details-modal').remove();
				jQuery('.modal-backdrop').remove();
				},500);
		}
	</script>
	<?php echo ob_get_clean(); ?>