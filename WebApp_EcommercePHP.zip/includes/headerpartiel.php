<!-- Header -->
	<div id="partial-headerWrapper">
		<div id="partial-back-flower"></div>
		<div id="partial-logotext"></div>
		<div id="partial-fore-flower"></div>
	</div>

	<div class="container-fluid">