<nav class="navbar navbar-default navbar-fixed-top">
		<div class="container">
		<a href="/EcommerceShipping/admin/index.php" class="navbar-brand">Workinc Ecommerce</a>
		<ul class="nav navbar-nav">

			<li><a href="produits.php">Produits</a></li>
			<li><a href="marques.php">Marques</a></li>
			<li><a href="categories.php">Catégories</a></li>
			<li><a href="archived.php">Archives</a></li>
			<?php if (has_permission('admin')): ?>
				<li><a href="users.php">Utilisateurs</a></li>
			<?php endif; ?>
			<li class="dropdown">
				<a href="#" class="dropdown-toggle" data-toggle="dropdown">Bonjour <?= $user_data['first']; ?>!
					<span class="caret"></span>
				</a>
				<ul class="dropdown-menu" role="menu">
					<li><a href="change_password.php">Changer le mot de passe</a></li>
					<li><a href="logout.php">Se déconnecter</a></li>
				</ul>
			</li>

			<!-- <li class="dropdown">
				<a href="#" class="dropdown-toggle" data-toggle="dropdown"><? //php echo $parent['categorie']; ?><span class="caret"></span></a>
				<ul class="dropdown-menu" role="menu">
					<?php // while($child = mysqli_fetch_assoc($cquery)) : ?>
					<li><a href="#"><?php //echo $child['categorie']; ?></a></li>  
				<?php //endwhile; ?>
				</ul>
			</li> -->
		
		
		</div>
	</nav>