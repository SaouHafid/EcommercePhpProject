<!DOCTYPE html>
<html>
<head>
  	<body> 
		<title>Administrateur</title> 
		<link rel="stylesheet" href="../css/bootstrap.min.css">
		<link rel="stylesheet" href="../css/bootstrap.css">
		<link rel="stylesheet" href="../css/main.css">	
		<link rel="stylesheet" href="../css/bootstrap-theme.css">
		<link rel="stylesheet" href="../css/bootstrap-theme.min.css">

		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
		<script src="../js/bootstrap.min.js"></script> 
</head>
<body>
	
	<div class="container-fluid">