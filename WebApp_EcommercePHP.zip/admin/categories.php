<?php 
 	require_once $_SERVER['DOCUMENT_ROOT'].'/EcommerceShipping/core/init.php'; 
 	if (!is_logged_in()){
 		login_error_redirect();
 	}
 	include 'includes/head.php';
 	include 'includes/navigation.php';

 	$sql = "SELECT * FROM categories WHERE parent = 0";
 	$res = $db->query($sql);
 	$errors = array();
 	$categorie = '';
 	$post_parent = ''; 

 	//Modfier une categorie: 
 	if (isset($_GET['edit']) && !empty($_GET['edit'])){
 		$edit_id = (int)$_GET['edit'];
 		$edit_id = sanitize($edit_id);
 		$edit_sql = "SELECT * FROM categories WHERE id = '$edit_id'"; 
 		$edit_result = $db->query($edit_sql); 
 		$edit_categorie = mysqli_fetch_assoc($edit_result);
 	}
 	//Supprimer une categorie: 
 	if (isset($_GET['delete']) && !empty($_GET['delete'])) {
 		$delete_id = (int)$_GET['delete'];
 		$delete_id = sanitize($delete_id);
 		$sql = "SELECT * FROM categories WHERE id = '$delete_id'";
 		$res = $db->query($sql);
 		$categorie = mysqli_fetch_assoc($res); 
 		if ($categorie['parent'] == 0){
 			$sql = "DELETE FROM categories WHERE parent = '$delete_id'";
 			$db->query($sql);
 		}
 		$dsql = "DELETE FROM categories WHERE id = '$delete_id'";
 		$db->query($dsql);
 		header("Location: categories.php"); 
 	}

 	//Form processus:
 	if (isset($_POST) && !empty($_POST)){
 		$post_parent = sanitize($_POST['parent']);
 		$categorie = sanitize($_POST['categorie']);
 		$sqlform = "SELECT * FROM categories WHERE categorie = '$categorie' AND parent = '$post_parent'";
 		if (isset($_GET['edit'])){
 			$id = $edit_categorie['id'];
 			$sqlform = "SELECT * FROM categories WHERE categorie = '$categorie' AND parent = '$post_parent' AND id != '$id'"; 
 		}
 		$fres = $db->query($sqlform);
 		$count = mysqli_num_rows($fres);
 		//if it's blank
 		if ($categorie == ''){
 			$errors[] .= 'Impossible! Tapez une catégorie.';
 		}
 		//if its already in DB
 		if ($count > 0) {
 			$errors[] .= $categorie.'Impossible! La catégorie existe déjà. Vueillez taper une autre!';
 		}

 		//Afficher les erreurs ou mis a jour de DB
 		if(!empty($errors)){
 			$display = display_errors($errors); 
 			?>
 			<script>
 				jQuery('document').ready(function()){

 					jQuery('#errors').html('<?=$display; ?>'); 
 				});
 			</script>
 			<?php }else{
 				//Mis a jour de la base de donnees:
 				$updatesql = "INSERT INTO categories (categorie, parent) VALUES ('$categorie', '$post_parent')";
 				if (isset($_GET['edit'])){ 
 					$updatesql = "UPDATE categories SET categorie = '$categorie', parent ='$post_parent' WHERE id = '$edit_id'"; 
 				}
 				$db->query($updatesql);
 				header("Location: categories.php");
 			}	
 	}
 	
 	$categorie_value = '';
 	$parent_value = 0;
 	if (isset($_GET['edit'])){
 		$categorie_value = $edit_categorie['categorie'];
 		$parent_value = $edit_categorie['parent'];
 	}else{
 		if (isset($_POST)) {
 			$categorie_value = $categorie;
 			$parent_value = $post_parent;
 		}
 	}
?>

<h2 class="text-center">Catégories</h2><hr>
<div class="row">

<!-- Formulaire de marques -->
	<div class="col-md-5">
		<form class="form" action="categories.php<?=((isset($_GET['edit']))?'?edit'.$edit_id:''); ?>" method="post">
			<legend><?=((isset($_GET['edit']))?'Modfier une ':'Ajouter une '); ?>catégorie</legend>
			<div id="errors"></div>
			<div class="form-group">
				<label for="parent">Parent</label>
				<select class="form-control" name="parent" id="parent">
					<option value="0"<?=(($parent_value == 0)?'selected="selected"':''); ?>>Parent</option>
					<?php while ($parent = mysqli_fetch_assoc($res)) : ?>
						<option value="<?= $parent['id']; ?>"
							<?=(($parent_value == $parent['id'])?' selected="selected"':''); ?>><?= $parent['categorie']; ?></option>	
					<?php endwhile; ?>			
				</select>	
			</div>  
			<div class="form-group">
				<label for="categorie">Catégorie</label>
				<input type="text" name="categorie" id="categorie" class="form-control" value="<?=$categorie_value;?>">
			</div>		
			<div class="form-group">
				<input type="submit" value="<?=((isset($_GET['edit']))?'Modfier':'Ajouter'); ?>" class="btn btn-success">
			</div>			
		</form>	
	</div>

<!-- Categories Table -->
		<div class="col-md-6">
			<table class="table table-bordered">
				<thead>
					<th>Catégorie</th><th>Parent</th><th></th>
				</thead>
				<tbody>
					<?php 
					$sql = "SELECT * FROM categories WHERE parent = 0";
 					$res = $db->query($sql);
					while ($parent = mysqli_fetch_assoc($res)) : 
					$parent_id = (int)$parent['id'];
					$sql2 = "SELECT * FROM categories WHERE parent = '$parent_id'";
					$cres = $db->query($sql2); 
					?>
					<tr class="bg-primary">
						<td><?=$parent['categorie']; ?></td>
						<td>Parent</td>
						<td>
							<a href="categories.php?edit=<?=$parent['id'];?>" class="btn btn-xs btn-default"><span class="glyphicon glyphicon-pencil"></span></a>
							<a href="categories.php?delete=<?=$parent['id'];?>" class="btn btn-xs btn-default"><span class="glyphicon glyphicon-remove-sign"></span></a> 
						</td> 
					</tr>

					<?php while ($child = mysqli_fetch_assoc($cres)) : ?>
					<tr class="bg-info">
						<td><?=$child['categorie']; ?></td>
						<td><?=$parent['categorie']; ?></td>
						<td>
							<a href="categories.php?edit=<?=$child['id'];?>" class="btn btn-xs btn-default"><span class="glyphicon 		glyphicon-pencil"></span></a>
							<a href="categories.php?delete=<?=$child['id'];?>" class="btn btn-xs btn-default"><span class="glyphicon glyphicon-remove-sign"></span></a> 
						</td> 
					</tr>
				<?php endwhile; ?>
				<?php endwhile; ?>
				</tbody>
			</table>
		</div>
	</div>

<?php include 'includes/footer.php'; ?> 