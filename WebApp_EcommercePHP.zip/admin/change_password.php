<?php
require_once $_SERVER['DOCUMENT_ROOT'].'/EcommerceShipping/core/init.php';
if (!is_logged_in()){
 		login_error_redirect();
 	}
include 'includes/head.php';

$hashed = $user_data['password'];  
$old_password = ((isset($_POST['old_password']))?sanitize($_POST['old_password']):'');
$old_password = trim($old_password);
$password = ((isset($_POST['password']))?sanitize($_POST['password']):'');
$password = trim($password);
$confirm = ((isset($_POST['confirm']))?sanitize($_POST['confirm']):'');
$confirm = trim($confirm);
$new_hashed = password_hash($password, PASSWORD_DEFAULT);
$user_id = $user_data['id'];
$errors = array();
?>

<style type="text/css">
	#login-form{
	width: 50%;
	height: 60%;
	border: 2px solid #000;
	border-radius:15px;
	box-shadow: 7px 7px 15px rgba(0,0,0,0.6);
	margin: 7% auto;
	padding: 15px; 
	background-color: #fff; 
	}
</style>

<div id="login-form">
	<div>
		<?php
	if ($_POST){
	  //form validation
	  if(empty($_POST['old_password']) || empty($_POST['password']) || empty($_POST['confirm'])){
	    $errors[]= "Vous devez remplir les 3 champs.";
	  }
	  //password is more than 6 characters
	  if(strlen($password) < 6){
	    $errors[] = 'Le mot de passe doit contenir 7 caractères au minimum';
	  }
	  //check
	  if ($password != $confirm){
	  	$errors[] = "Le nouveau mot de passe et le mot de passe confimé ne se rassemeblent pas.";
	  }
	  if(strcmp($old_password, $hashed) != 0){
	    $errors[] = "L'ancien mot de passe n'est pas correct.";
	  }

	  //check for errors
	  if(!empty($errors)){
	    echo display_errors($errors);

	  }else{
	    //log user in
	    $db->query("UPDATE users SET password = '$new_hashed' WHERE id = '$user_id'");
	    $_SESSION['succes_flash'] =  'Vous bien changé votre mot de passe!';
	    header('Location: index.php');
	  }
	}
	?>

	</div>
<h2 class="text-center">Changer le mot de passe</h2><hr>
  <form action="change_password.php" method="post">
    <div class="form-group">
      <label for= "old_password">L'ancien mot de passe:</label>
      <input type="password" name="old_password" id="old_password" class="form-control" value="<?=$old_password?>">
    </div>
    <div class="form-group">
      <label for= "password">Le nouveau mot de passe:</label>
      <input type="password" name="password" id="password" class="form-control" value="<?=$password;?>">
    </div>
    <div class="form-group">
      <label for= "confirm">Confirmer le mot de passe:</label>
      <input type="password" name="confirm" id="confirm" class="form-control" value="<?=$confirm;?>"> 
    </div>
    <div class="form-group">
      <a href="index.php" class="btn btn-default">Annuler</a> 
      <input type="submit" value="Assurer le changement du mot de passe" class="btn btn-primary">
    </div>
  </form>
  <!-- <p class= "text-right"><a href="/EcommerceShipping/index.php" alt="home">Visiter le site</a></p> -->
</div>

<?php include 'includes/footer.php'; ?>﻿
  
