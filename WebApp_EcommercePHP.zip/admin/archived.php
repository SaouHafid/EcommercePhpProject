<?php
 require_once $_SERVER['DOCUMENT_ROOT'].'/EcommerceShipping/core/init.php';
 if (!is_logged_in()){
    login_error_redirect();
  }
 include 'includes/head.php';
 include 'includes/navigation.php';

 if(isset($_GET['archived']))
 {
  $p_id = sanitize($_GET['archived']);
  $reset = "UPDATE produits SET supprime = 0,distingue = 1 WHERE id = '$p_id'";
  $result = $db->query($reset);
  header('Location: archived.php');
 }
$sql = "SELECT * FROM produits WHERE supprime = 1";
$products_result = $db->query($sql);
?>
<h2 class="text-center">Produits supprimés</h2>
<hr>
<table class="table-bordered table-condensed table-striped">
 <thead>
  <th>Restore</th>
  <th>Products</th>
  <th>Price</th>
  <th>List Price</th> 
  <th>Category</th>
  <th>description</th>
  <th>Sold</th>
 </thead>
 <tbody>
      <?php while($product = mysqli_fetch_assoc($products_result)): 
   
       $childID = $product['categorie']; 
       $catsql = "SELECT * FROM categories WHERE id='$childID'";
       $cat_result = $db->query($catsql);
       $child = mysqli_fetch_assoc($cat_result);
       $parentID = $child['parent'];
       $p_sql = "SELECT * FROM categories WHERE id='$parentID'";
       $presult = $db->query($p_sql);
       $parent = mysqli_fetch_assoc($presult);
       $category = $parent['categorie'].' ~ '.$child['categorie'];
   ?>
    <tr>
     <td>
     <a href="archived.php?archived=<?=$product['id'];?>" class="btn btn-xs btn default"><span class="glyphicon glyphicon-refresh
"></span></a>   
   </td>
     <td><?=$product['titre'];?></td>
     <td><?=$product['prix'];?></td>
     <td><?=$product['list_prix'];?></td>
     <td><?=$category;?></td>
     <td><?=$product['description'];?></td>
     <td>0</td>

    </tr>
   <?php endwhile; ?>
 </tbody>
</table>

<?php include 'includes/footer.php';

 ?>﻿