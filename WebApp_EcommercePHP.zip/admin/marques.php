<?php 
 	require_once '../core/init.php'; 
 	if (!is_logged_in()){
 		login_error_redirect();
 	}
 	include 'includes/head.php';
 	include 'includes/navigation.php';

 	//Extraire depuis la DB
 	$sql = "SELECT * FROM marque ORDER BY marque";
 	$res = $db->query($sql);
 	$errors = array();

 	//Editer une marque:
 	if (isset($_GET['edit']) && !empty($_GET['edit'])) {
 		$edit_id = (int)$_GET['edit'];
 		$edit_id = sanitize($edit_id);
 		$sql2 = "SELECT * FROM marque WHERE id = '$edit_id'"; 
 		$edit_result = $db->query($sql2);
 		$eBrand = mysqli_fetch_assoc($edit_result); 
 	}

 	//Suppresion d'une marque:
 	if (isset($_GET['delete']) && !empty($_GET['delete'])) {
 		$delete_id = (int)$_GET['delete'];
 		$delete_id = sanitize($delete_id);
 		$sql = "DELETE FROM marque WHERE id = '$delete_id'"; 
 		$db->query($sql);
 		header("Location: marques.php");
 	}

 	//Si add form is submitted !
 	if (isset($_POST['add_submit'])) {
 		$marque = sanitize($_POST['marque']);

 		if ($_POST['marque'] == '') {
 			 $errors[] .= 'Tapez une marque!'; 
 		}
	//CHECK 
 	$sql = "SELECT * FROM marque WHERE marque = '$marque'";
 	if (isset($_GET['edit'])){
 		$sql = "SELECT * FROM marque WHERE marque ='$marque' AND id != '$edit_id'";
 	}
 	$res = $db->query($sql);
 	$count = mysqli_num_rows($res);
 	//Existe deja
 	if ($count > 0) {
 		$errors[] .=$marque.' Cette marque existe déjà! Choisisissez une autre..';
 	}

 	//Affichage errors:
 	if (!empty($errors)){
 		echo display_errors($errors);
 	}else{
 		$sql = "INSERT INTO marque (marque) VALUES ('$marque')";
 		if (isset($_GET['edit'])){
 			$sql = "UPDATE marque SET marque = '$marque' WHERE id = '$edit_id'"; 
 		}
 		$db->query($sql);
 		header('Location: marques.php'); 
 	}
 }
?>
<h2 class="text-center">Marques</h2><hr>
<!-- Formulaire de marques -->
<div class="text-center">
	<form class="form-inline" action="marques.php<?=((isset($_GET['edit']))?'?edit='.$edit_id:''); ?>" method="post">
		<div class="form-group">
		<label for="marque"><?=((isset($_GET['edit']))?'Modifier une':'Ajouter une'); ?> marque:</label>
		<input type="text" name="marque" id="brand" class="form-control" value="<?= ((isset($_POST['marque']))?$_POST['marque']:''); ?>">
		<?php if (isset($_GET['edit'])): ?>
			<a href="marques.php" class="btn btn-default">Annuler</a>
		<?php endif; ?>  
		<input type="submit" name="add_submit" value="<?=((isset($_GET['edit']))?'Modifier une':'Ajouter une'); ?> marque" class="btn btn-success">			
		</div>
	</form>
</div>
<hr>  
<table class="table table-bordered table-striped table-auto table-condensed"> 
	<thead> 
		<th> 
			<th>Marque</th>
		</th><th></th>
	</thead> 
	<tbody>
		<?php while ($marque = mysqli_fetch_assoc($res)) : ?>
		<tr>

		<td><a href="marques.php?edit=<?= $marque['id']; ?>" class="btn btn-xs btn-default">
			<span class="glyphicon glyphicon-pencil"></span></a></td>
		<td><?= $marque['marque']; ?></td>
		<td><a href="marques.php?delete=<?= $marque['id']; ?>" class="btn btn-xs btn-default">
			<span class="glyphicon glyphicon-remove-sign"></span></a></td>

		</tr>    

	<?php endwhile; ?>
	</tbody> 
</table>

<?php include 'includes/footer.php'; ?>