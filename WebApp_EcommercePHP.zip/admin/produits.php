<?php
require_once $_SERVER['DOCUMENT_ROOT'].'/EcommerceShipping/core/init.php';
if (!is_logged_in()){
 		login_error_redirect();
 	}
include 'includes/head.php';
include 'includes/navigation.php';

//Suppression d'un produit: 
if (isset($_GET['delete'])){
	$delete_id = sanitize($_GET['delete']);
	$sqldelete = "UPDATE produits SET supprime = 1 WHERE id = '$delete_id'";
	$db->query($sqldelete);
	header("Location: produits.php");
}

$dbpath = '';
if (isset($_GET['add']) || isset($_GET['edit'])){
	$marqueQuery = $db->query("SELECT * FROM marque ORDER BY marque");
	$parentQuery = $db->query("SELECT * FROM categories WHERE parent = 0 ORDER BY categorie");
	$titre = ((isset($_POST['titre']) && $_POST['titre'] != '')?sanitize($_POST['titre']):'');
	$marque = ((isset($_POST['marque']) && !empty($_POST['marque']))?sanitize($_POST['marque']):'');
	$parent = ((isset($_POST['parent']) && !empty($_POST['parent']))?sanitize($_POST['parent']):'');
	$categorie = ((isset($_POST['child']) && !empty($_POST['child']))?sanitize($_POST['child']):'');
	$prix = ((isset($_POST['prix']) && !empty($_POST['prix']))?sanitize($_POST['prix']):'');
	$list_prix = ((isset($_POST['list_prix']) && !empty($_POST['list_prix']))?sanitize($_POST['list_prix']):''); 
	$description = ((isset($_POST['description']) && !empty($_POST['description']))?sanitize($_POST['description']):'');
	$tailles = ((isset($_POST['tailles']) && !empty($_POST['tailles']))?sanitize($_POST['tailles']):'');
	$tailles = rtrim($tailles,',');
	$saved_image = '';

		if (isset($_GET['edit'])){
			$edit_id = (int)$_GET['edit'];
			$produitres = $db->query(" SELECT * FROM produits WHERE id = '$edit_id'");
			$produit = mysqli_fetch_assoc($produitres);
			if (isset($_GET['delete_image'])){
				$image_url = $SERVER['DOCUMENT_ROOT'].$produit['image'];
				unlink($image_url);
				$db->query("UPDATE produits SET image = '' WHERE id = '$edit_id'");
				header('Location: produits.php?edit='.$edit_id); 
			}
			$categorie = ((isset($_POST['child']) && $_POST['child'] != '')?sanitize($_POST['child']):$produit['categorie']);
			$titre = ((isset($_POST['titre']) && $_POST['titre'] != '')?sanitize($_POST['titre']):$produit['titre']); 
			$marque = ((isset($_POST['marque']) && $_POST['marque'] != '')?sanitize($_POST['marque']):$produit['marque']);
			$parentQ = $db->query("SELECT * FROM categories WHERE id ='$categorie'");
			$parentRes = mysqli_fetch_assoc($parentQ);  
			$parent = ((isset($_POST['parent']) && $_POST['parent'] != '')?sanitize($_POST['parent']):$parentRes['parent']);
			$prix = ((isset($_POST['prix']) && $_POST['prix'] != '')?sanitize($_POST['prix']):$produit['prix']);
			$list_prix = ((isset($_POST['list_prix']) && $_POST['list_prix'] != '')?sanitize($_POST['list_prix']):$produit['list_prix']);
  $description = ((isset($_POST['description']) && $_POST['description'] != '')?sanitize($_POST['description']):$produit['description']);
  			$tailles = ((isset($_POST['tailles']) && $_POST['tailles'] != '')?sanitize($_POST['tailles']):$produit['tailles']);
  			$tailles = rtrim($tailles,',');
  			$saved_image = (($produit['image'] != '')?$produit['image']:'');
  			$dbpath = $saved_image;
		}
		if (!empty($tailles)){
			# code...
		$sizeString = sanitize($tailles);
		$sizeString = rtrim($sizeString,',');
		$sizesArray = explode(',',$sizeString);
		$sArray = array();
		$qArray = array();
		foreach ($sizesArray as $ss){
			$s = explode(':', $ss);
			$sArray[] = $s[0];
			$qArray[] = $s[1];
		}
	} 
	else{$sizesArray = array();}

	if ($_POST){

		//$dbpath = '';
		$errors = array();

	$required = array('titre', 'marque', 'prix', 'parent', 'child', 'tailles');
        foreach($required as $field){
            if($_POST[$field] == ''){
                $errors[] = 'Tous les champs avec un astérisque sont requis.';
                break;
            }
        }
    if(!empty($_FILES)){
       	$image = $_FILES['image'];

   		if($image['name']!='' && $image['type']!='') {
    	//var_dump($_FILES);
    	$image = $_FILES['image'];
   		// var_dump($photo);
    	$name = $image['name'];
    	//var_dump($name);
    	$nameArray = explode('.', $name);
    	$fileName = $nameArray[0];
    	$fileExt = $nameArray[1];
    	$mime = explode('/', $image['type']);
    	$mimeType = $mime[0];
    	$mimeExt = $mime[1];
    	$tmpLoc = $image['tmp_name'];
    	$fileSize = $image['size'];

    	$allowed = array('png', 'jpg', 'jpeg', 'gif');
    	$uploadName = md5(microtime()).'.'.$fileExt;
    	$uploadPath = BASEURL.'images/products/'.$uploadName;
    	$dbpath = '/EcommerceShipping/images/products/'.$uploadName;
    	if($mimeType != 'image') {
     	$errors[] .= 'Le fichier doit être une image.';
    	}
		if(!in_array($fileExt, $allowed)) {
		 $errors[] .= "Les extensions d'images permis sont: png, jpg, jpeg ou gif.";
		}
		if($fileSize > 15000000) {
		 $errors[] .= "Le volume maximum d'image est: 15MB.";
		}
		if($fileExt != $mimeExt && ($mimeExt == 'jpeg' && $fileExt != 'jpg')) {
		 $errors[] .= "L'extension de fichier ne correspond pas au fichier.";
		}
		}
	}

	if(!empty($errors)){
        echo display_errors($errors);
        }else{
        	//import du fichier et insertion dans la DB
        	if (!empty($_FILES)) {
            move_uploaded_file($tmpLoc,$uploadPath);
            }
            $insertSql = "INSERT INTO produits (`titre`, `prix`, `list_prix`, `marque`, `categorie`, `image`, `description`, `distingue`, `tailles`, `supprime`) VALUES ('$titre', '$prix', '$list_prix', '$marque', '$categorie', '$dbpath', '$description', '0', '$tailles', '0')"; 
            if (isset($_GET['edit'])){
 	          $insertSql = "UPDATE produits SET titre = '$titre', prix = '$prix', list_prix = '$list_prix', marque = '$marque', categorie = '$categorie', image = '$dbpath', description = '$description', tailles = '$tailles' WHERE id = '$edit_id'";
             } 
			$db -> query($insertSql);
            header('Location: produits.php'); 
        }
    }
?>
	<h2 class="text-center"><?=((isset($_GET['edit']))?'Modifier un':'Ajouter un nouvrau'); ?> produit</h2>
	<hr>
	<form action="produits.php?<?=((isset($_GET['edit']))?'edit='.$edit_id:'add=1'); ?>" method="POST" enctype="multipart/form-data">
	 <div class="form-group col-md-3">
	  	<label for="titre">Titre*:</label>
	  	<input type="text" name="titre" class="form-control" id="titre" value="<?=$titre; ?>">
	 </div>

	 <div class="form-group col-md-3">
		 <label for="marque">Marque*:</label>
		 <select class="form-control" id="marque" name="marque">
			 <option value=""<?= (($marque == '')?'selected':''); ?>></option>
		 	 <?php while($m = mysqli_fetch_assoc($marqueQuery)): ?>
		  	 <option value = "<?=$m['id'];?>"<?= (($marque == $m['id'])?' selected':'');?>>  
		  	 <?=$m['marque'];?></option>
		  <?php endwhile; ?>
		 </select>
	</div>
 	
 	<div class="form-group col-md-3">
		 <label for="marque">Catégorie parentale*:</label>
		 <select class="form-control" id="parent" name="parent">
		 	<option value=""<?=(($parent == '')?'selected':'');?>></option>
		 		<?php while($p = mysqli_fetch_assoc($parentQuery)): ?>
		 	<option value=" <?=$p['id'];?>"<?=(($parent == $p['id'])?' selected':'');?>>
		 		<?=$p['categorie'];?></option>
		 	<?php endwhile; ?> 
 		</select>
 	</div>

 	<div class="form-group col-md-3">
		 <label for="child">Catégorie infantile*:</label>
			 <select id="child" name="child" class="form-control">
		 	</select>
	</div>
	<div class="form-group col-md-3">
	 	<label for="prix">Prix*:</label>
	 	<input type="text" id="prix" name="prix" class="form-control" 
	 		   value="<?=$prix;?>">
	 </div>
	 <div class="form-group col-md-3">
		 <label for="list_prix">Liste des prix:</label>
		 <input type="text" id="list_prix" name="list_prix" class="form-control" 
		 		value="<?=$list_prix;?>">
 	 </div>
 	 <div class ="form-group col-md-3">
		 <label>Quantité & Tailles*:</label>  
	  	 <button class="btn btn-default form-control" onclick="jQuery('#sizesModal').modal('toggle');return false;">
	  	 	Quantité & Tailles
	  	 </button>
	</div>
	<div class="form-group col-md-3">
		 <label for="tailles">Tailles & Aperçu des quantités:</label>
		 <input type="text" class="form-control" name="tailles" id="tailles" 
		 		value="<?=$tailles;?>" readonly>
 	</div> 
 	<div class="form-group col-md-6">
 		<?php if ($saved_image != ''): ?>
 			<div class="saved-image">
 				<img src="<?=$saved_image;?>" alt="image sauvegardé"><br>
 				<a href="produits.php?delete_image=1&edit=<?=$edit_id;?>" class="text-danger">Supprimer l'image</a>
 			</div>
 		<?php else: ?>
	 	<label for="image">Image du produit:</label>
	 	<input type="file" name="image" id="image" class="form-control">
	 	<?php endif; ?>
	</div>
 	<div class="form-group col-md-6">
 		<label for="description">Description:</label>
		 <textarea id="description" name="description" class="form-control" rows="6">
 		<?=$description;?></textarea>
 	</div>
 		<div class="form-group pull-right">
 		 <a href="produits.php" class="btn btn-default">Annuler</a>
 		 <input type="submit" value="<?=((isset($_GET['edit']))?'Modifier':'Ajouter'); ?>" class="btn btn-success">
 	</div>
 	<div class="clearfix"></div>

	</form>
	<!-- Button trigger modal
	<button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#myModal">
	  Launch demo modal
	</button>  -->
	<!-- Modal -->
	<div class="modal fade" id="sizesModal" tabindex="-1" role="dialog" aria-labelledby="sizesModalLabel" aria-hidden="true">
	  	<div class="modal-dialog modal-lg" role="document">
	    	<div class="modal-content">
	      		<div class="modal-header">
	        	<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span>
	        	</button>
	        <h4 class="modal-title" id="sizesModalLabel">Taille & Quantité</h4>
	      	</div>
	      	<div class="modal-body">
	      		<div class="container-fluid">
	        	<?php for($i = 1; $i <= 12; $i++): ?>
                	<div class="form-group col-md-4">
                  	<label for="size<?=$i;?>">Taille:</label>
                    <input type="text" name="size<?=$i;?>" id="size<?=$i;?>" value="<?=((!empty($sArray[$i-1]))?$sArray[$i-1]:'');?>"
                    	   class="form-control">
                </div>
                <div class="form-group col-md-2"> 
                    <label for="qty<?=$i;?>">Quantité:</label>
                    <input type="number" name="qty<?=$i;?>" id="qty<?=$i;?>" value="<?=((!empty($qArray[$i-1]))?$qArray[$i-1]:'');?>" min="0" class="form-control">
                </div>
              	<?php endfor; ?>
	      		</div>
	      	</div>
	      	<div class="modal-footer">
	        <button type="button" class="btn btn-default" data-dismiss="modal">Fermer</button>
	        <button type="button" class="btn btn-primary" onclick="updateTailles();jQuery('#sizesModal').modal('toggle'); return false;">Sauvegarder les modifications</button>
	      	</div>
	    </div>
	  </div>
	</div>
<?php }else{
$sql = "SELECT * FROM produits WHERE supprime = 0"; 
$pres = $db->query($sql);
if (isset($_GET['distingue'])){
	$id = (int)$_GET['id'];
	$distingue = (int)$_GET['distingue'];
	$distingueSql = "UPDATE produits SET distingue = '$distingue' WHERE id = '$id'";
	$db->query($distingueSql);
	header("Location: produits.php");
}
?>

<h2 class="text-center">Produits</h2>
<a href="produits.php?add=1" class="btn btn-success pull-right" id="add-product-btn">Ajouter un produit</a><div class="clearfix"></div>
<hr>
<table class="table table-bordered table-condensed table-striped">
	<thead><th></th><th>Produit</th><th>Prix</th><th>Catégorie</th><th>Distingué</th><th>Solde</th></thead>

	<tbody>
		<?php while($produit = mysqli_fetch_assoc($pres)): 
			$childID = $produit['categorie'];
			$catSql = "SELECT * FROM categories WHERE id = '$childID'";
			$res = $db->query($catSql);
			$child = mysqli_fetch_assoc($res);
			$parentID = $child['parent'];
			$pSql = "SELECT * FROM categories WHERE id = '$parentID'";
			$presult = $db->query($pSql);
			$parent = mysqli_fetch_assoc($presult);
			$categorie = $parent['categorie'].'-'.$child['categorie'];
		?>
			<tr>
			<td>
<a href="produits.php?edit=<?= $produit['id']; ?>" class="btn btn-xs btn-default"><span class="glyphicon glyphicon-pencil"></span></a>
<a href="produits.php?delete=<?= $produit['id'] ?>" class="btn btn-xs btn-default"><span class="glyphicon glyphicon-remove"></span></a>
			</td>
				<td><?= $produit['titre'];?></td>
				<td><?= money($produit['prix']); ?></td>
				<td><?= $categorie; ?></td>
	<td><a href="produits.php?distingue=<?=(($produit['distingue'] == 0 )?'1':'0');?>&id=<?=$produit['id'];?>" class="btn btn-xs btn-default"><span class="glyphicon glyphicon-<?=(($produit['distingue'] == 1)?'minus':'plus'); ?>"></span></a>
	&nbsp <?=(($produit['distingue'] == 1)?'Produit distingué':'');?></td> 
				<td></td>
			</tr>
		<?php endwhile; ?>
	</tbody>
</table>

<?php } include 'includes/footer.php'; ?>

<script>
	jQuery('document').ready(function(){
		get_child_options('<?= $categorie;?>');
	});

</script>