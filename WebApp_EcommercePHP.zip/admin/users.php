<?php 
 	require_once '../core/init.php';
 	if (!is_logged_in()){
 		login_error_redirect();
 	}
 	if (!has_permission('admin')){
 		permission_error_redirect('index.php');
 	}
 	include 'includes/head.php';
 	include 'includes/navigation.php';

	//Suppression:	
	if(isset($_GET['delete'])){
	 $delete_id = sanitize($_GET['delete']);
	 $db->query("DELETE FROM users WHERE id = '$delete_id'");
	 $_SESSION['success_flash'] = 'Un utilisateur a été supprimé';
	 header('Location: users.php');
	}
	if (isset($_GET['add'])) {
		 $name = ((isset($_POST['name']))?sanitize($_POST['name']):'');
 		 $email = ((isset($_POST['email']))?sanitize($_POST['email']):'');
		 $password = ((isset($_POST['password']))?sanitize($_POST['password']):'');
		 $confirm = ((isset($_POST['confirm']))?sanitize($_POST['confirm']):'');
		 $permissions = ((isset($_POST['permissions']))?sanitize($_POST['permissions']):'');
		 $errors = array();
		 if($_POST){
			  $emailQuery = $db->query("SELECT * FROM users WHERE email = '$email'");
			  $emailCount = mysqli_num_rows($emailQuery);
			  
			  if($emailCount != 0){
			   $errors[] = "L'email déjà existe dans le site par une autre personne!";
			  }
			  
			  $required = array('name', 'email', 'password', 'confirm', 'permissions');
			  foreach($required as $f){
			   if(empty($_POST[$f])){
			    $errors[] = 'Vous devez remplir tous les champs!';
			    break;
			   }
			  }
			  if(strlen($password) <6){
			   $errors[] = 'Le mot de passe doit contenir 7 caractères au minimum!';
			  }
			  
			  if($password != $confirm){
			   $errors[] = 'Les deux mots de passe que vous avez saisi ne se rassemblent pas!';
			  }
			  
			  if(!filter_var($email,FILTER_VALIDATE_EMAIL)){
			   $errors[] = "L'email n'est pas valid!";
			  }
			  
			  if(!empty($errors)){
			   echo display_errors($errors);
			  }else{
			   //add user to db
			   $hashed = password_hash($password,PASSWORD_DEFAULT);
			   $db->query("INSERT INTO users (name,email,password,joinDate,lastLogin,permissions) 
			   					VALUES ('$name', '$email', '$hashed', '2017-09-23 00:06:44', '2017-09-24 00:51:50', '$permissions') ");
			   $_SESSION['success_flash'] = 'Un utilisateur a été bien ajouté à la base de données.';
			   header('Location: users.php');
			  }
			 }
 
		?>

		<h2 class="text-center">Ajouter un utilisateur</h2><hr>
		 <form action="users.php?add=1" method="post">
		  <div class="form-group col-md-6">
		   <label for="name">Nom et prénom:</label>
		   <input type="text" name="name" id="name" class="form-control" value="<?=$name;?>">
		  </div>
		  <div class="form-group col-md-6">
		   <label for="email">Email:</label>
		   <input type="email" name="email" id="email" class="form-control" value="<?=$email;?>">
		  </div>
		  <div class="form-group col-md-6">
		   <label for="password">Mot de passe:</label>
		   <input type="password" name="password" id="password" class="form-control" value="<?=$password;?>">
		  </div>
		  <div class="form-group col-md-6">
		   <label for="confirm">Confirmer le mot de passe:</label>
		   <input type="password" name="confirm" id="confirm" class="form-control" value="<?=$confirm;?>">
		  </div>
		  <div class="form-group col-md-6">
		   <label for="name">Permissions:</label>
		   <select class="form-control" name="permissions">
		    <option value=""<?=(($permissions == '')?' selected':'');?>></option>
		    <option value="editor"<?=(($permissions == 'editor')?' selected':'');?>>Editor</option>
		    <option value="admin,editor"<?=(($permissions == 'admin,editor')?' selected':'');?>>Admin</option>
		   </select>
		  </div>
		  <div class="form-group col-md-6 text-right" style="margin-top:25px;">
		   <a href="users.php" class="btn btn-default">Annuler</a>
		   <input type="submit" value="Ajouter l'utilisateur" class="btn btn-primary">
		  </div>
		 </form>
	<?php
	}else{
	$userQuery = $db->query("SELECT * FROM users ORDER BY name");
	?>

La page d'Utilisateurs de l'application Workinc Ecommerce.

<h2>Utilisateurs</h2><br>

<a href="users.php?add=1" class="btn btn-success pull-right" id="add-produit-btn">Ajouter un utilisateur</a>
<hr>
<table class="table table-bordered table-striped table-condensed">
 <thead><th></th><th>Nom</th><th>Email</th><th>Date de jointure</th><th>Dernière connexion</th><th>Permissions</th></thead>
 <tbody>
 <?php while($user = mysqli_fetch_assoc($userQuery)): ?>
  <tr>
   <td>
    <?php if($user['id'] != $user_data['id']): ?>
     <a href="users.php?delete=<?=$user['id'];?>" class="btn btn-default btn-xs"><span class="glyphicon glyphicon-remove-sign"></span></a>
    <?php endif; ?>
   </td>
   <td><?=$user['name'];?></td> 
   <td><?=$user['email'];?></td>
   <td><?=bonne_date($user['joinDate']);?></td>
   <td><?=(($user['lastLogin'] == '0000-00-00 00:00:00')?'Jamais':bonne_date($user['lastLogin']));?></td>
   <td><?=$user['permissions'];?></td>
  </tr>
 <?php endwhile; ?>
 </tbody>
</table>

<?php } include 'includes/footer.php' ?>

	
