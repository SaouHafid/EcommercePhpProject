<?php
	require_once $_SERVER['DOCUMENT_ROOT'].'/EcommerceShipping/core/init.php';
	//$name = sanitize($_POST['nom']);
	$email = sanitize($_POST['email']);
	$adresse = sanitize($_POST['adresse']);
	$adresse2 = sanitize($_POST['adresse2']);
	$ville = sanitize($_POST['ville']);
	$region = sanitize($_POST['region']);
	$code_postal = sanitize($_POST['code_postal']);
	$errors = array();
	$required = array( 
		//'name' => 'Nom', 
		'email' => 'E-mail',
		'adresse' => 'Adresse', 
		'ville' => 'Ville',
		'region' => 'Région',
		'code_postal' => 'Code postale',
		);
	//Check if champs is vide 
	foreach ($required as $key => $value) {
		if (empty($_POST[$key]) || $_POST[$key] == ''){
			$errors[] = $value.' est requis.';
		}
	}
if (!filter_var($email,FILTER_VALIDATE_EMAIL)){
	$errors[] = 'Email non vaild.';
}

if (!empty($errors)){
	echo display_errors($errors);
}else{
	echo 'passed';
}
?>
