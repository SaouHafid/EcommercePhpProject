<?php
/*CHANGE ACCORDINGLY*/
require_once $_SERVER['DOCUMENT_ROOT'].'/EcommerceShipping/core/init.php';
 $produit_id = isset($_POST['produit_id'])? sanitize($_POST['produit_id']):'';
 $size = isset($_POST['size'])? sanitize($_POST['size']):'';
 $available = isset($_POST['available'])? sanitize($_POST['available']):'';
 $quantity = isset($_POST['quantity'])? sanitize($_POST['quantity']):'';
 $item = array();
 $item[] = array(
  'id'       =>$produit_id,
  'size'     =>$size,
  'quantity' =>$quantity,

 );
 
 $domain = ($_SERVER['HTTP_HOST'] != 'localhost')?'.'.$_SERVER['HTTP_HOST']:false;
 //$domain = '';
 $query = $db->query("SELECT * FROM produits WHERE id = '{$produit_id}'");
 $produit = mysqli_fetch_assoc($query);
 $_SESSION['success_flash'] = $produit['titre'].' a été ajouté à votre panier.';

 if ($cart_id != ''){
 	//
 	  $cartQ = $db->query("SELECT * FROM panier WHERE id = '{$cart_id}'");
	  $cart = mysqli_fetch_assoc($cartQ);
	  $previous_items = array();
	  $previous_items = json_decode($cart['elements'],true);
	  $item_match = 0;
	  $new_items = array();
	  foreach($previous_items as $pitem){
	   if($item[0]['id'] == $pitem['id'] && $item[0]['size'] == $pitem['size']){
	    	$pitem['quantity'] = $pitem['quantity'] + $item[0]['quantity'];
	    if($pitem['quantity'] > $available){
	     	$pitem['quantity'] = $available;
	     }
	    $item_match = 1;
	   }
	   $new_items[] = $pitem;
	   }
	  if($item_match != 1){
	   	   $new_items = array_merge($item,$previous_items);
	  }
	  $items_json = json_encode($new_items);
  	  $cart_expire = date("Y-m-d H:i:s", strtotime("+30 days"));
      $db->query("UPDATE panier SET elements = '{$items_json}', date_expire = '{$cart_expire}' WHERE id = '{$cart_id}'");
      setcookie(CART_COOKIE,'',1,"/",$domain,false);
      setcookie(CART_COOKIE,$cart_id,CART_COOKIE_EXPIRE,'/',$domain,false);

 	 }else{
  //add the cart to the database and set cookies 
	  $items_json = json_encode($item);
	  $cart_expire = date("Y-m-d H:i:s",strtotime("+30 days"));
	  $db->query("INSERT INTO panier (elements,date_expire) VALUES('{$items_json}','{$cart_expire}')");
	  $cart_id = $db->insert_id; //$db->insert_id will return the last id from the database and will set it to cart_id
	  setcookie(CART_COOKIE,$cart_id,CART_COOKIE_EXPIRE,'/',$domain,false);
	 }﻿

?> 
