<?php 
	  require_once 'core/init.php';  
	  include 'includes/head.php';
	  include 'includes/navigation.php';
	  include 'includes/headerfull.php'; 
	  include 'includes/leftbar.php'; 

	  $sql = "SELECT * FROM produits WHERE distingue = 1";
	  $featured = $db->query($sql);

?> 

	<!-- main container --> 
		<div class="col-md-8">
			<div class="row">
				<h2 class="text-center">Produits distingués</h2>
				<?php while ($produit = mysqli_fetch_assoc($featured)) : ?>
				<div class="col-sm-3 text-center">  
					<h4><?= $produit['titre']; ?></h4>
					<img src="<?= $produit['image']; ?>" alt="<?= $produit['titre']; ?>" class="img-thumb" />
					<p class="list-price text-danger">List Prix: <s>$<?= $produit['list_prix']; ?></s></p>
					<p class="price">Notre prix: $<?= $produit['prix']; ?></p> 
					<button type="button" class="btn btn-sm btn-success" onclick="detailsmodal(<?= $produit['id']; ?>)">Details</button>
				</div>

			<?php endwhile; ?>
				 
			</div>
		</div> 

<?php 	  
	  //include 'includes/details.php';
	  include 'includes/rightbar.php'; 
	  include 'includes/footer.php'; 
?>  