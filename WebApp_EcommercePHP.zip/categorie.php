<?php 
	  require_once 'core/init.php';  
	  include 'includes/head.php';
	  include 'includes/navigation.php';
	  include 'includes/headerpartiel.php'; 
	  include 'includes/leftbar.php'; 

	  if (isset($_GET['cat'])){
	  	 $cat_id = sanitize($_GET['cat']);
	  }else{
	  	$cat_id = '';
	  }

	  $sql = "SELECT * FROM produits WHERE categorie = '$cat_id'";
	  $produitQ = $db->query($sql);
	  $categorie = get_categorie($cat_id);

?> 

	<!-- main container --> 
		<div class="col-md-8">
			<div class="row"> 
				<h2 class="text-center"><?=$categorie['parent'].' '.$categorie['child']; ?></h2>
				<?php while ($produit = mysqli_fetch_assoc($produitQ)) : ?>
				<div class="col-sm-3 text-center">  
					<h4><?= $produit['titre']; ?></h4>
					<img src="<?= $produit['image']; ?>" alt="<?= $produit['titre']; ?>" class="img-thumb" />
					<p class="list-price text-danger">List Prix: <s>$<?= $produit['list_prix']; ?></s></p>
					<p class="price">Notre prix: $<?= $produit['prix']; ?></p> 
					<button type="button" class="btn btn-sm btn-success" onclick="detailsmodal(<?= $produit['id']; ?>)">Details</button>
				</div>

			<?php endwhile; ?>
				 
			</div>
		</div> 

<?php 	  
	  //include 'includes/details.php';
	  include 'includes/rightbar.php'; 
	  include 'includes/footer.php'; 
?>  