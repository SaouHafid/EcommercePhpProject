<?php
require_once 'core/init.php';
include 'includes/head.php';
include 'includes/navigation.php';
include 'includes/headerpartiel.php';

if($cart_id != ''){
  $cartQ = $db->query("SELECT * FROM panier WHERE id = '{$cart_id}'");
  $result = mysqli_fetch_assoc($cartQ);
  $items = json_decode($result['elements'],true);
  $i = 1;
  $sub_total = 0;
  $item_count = 0;
}
?>

<div class="col-md-12">
  <div class="row">
    <h2 class="text-center">Mon panier d'achat</h2><hr>
    <?php if($cart_id == ''): ?>
      <div class="bg-danger">
        <p class="text-danger text-center">
          Votre panier d'achat ne contient aucun produit!
        </p>
      </div>

    <?php else: ?>
      <table class="table table-bordered table-condensed table-striped">
       <thead><th>#</th><th>Elément</th><th>Prix</th><th>Quantité</th><th>Taille</th><th>Au Total</th></thead>
       <tbody>
        <?php
           foreach ($items as $item) {
             $product_id = $item['id'];
             $productQ = $db->query("SELECT * FROM produits WHERE id = '{$product_id}'");
             $product = mysqli_fetch_assoc($productQ);
             $sArray = explode(',',$product['tailles']);
             foreach ($sArray as $sizeString) {
               $s = explode(':',$sizeString);
               if($s[0] == $item['size']){
                 $available =$s[1];
               }
             }
             ?>
             <tr>
               <td><?=$i;?></td>
               <td><?=$product['titre'];?></td>
               <td><?=money($product['prix']);?></td>
               <td>
                 <button class="btn btn-xs btn-default" onclick="update_cart('removeone','<?=$product['id'];?>','<?=$item['size'];?>')">-</button>
                 <?=$item['quantity'];?>
                 <?php if($item['quantity'] < $available): ?>
                 <button class="btn btn-xs btn-default" onclick="update_cart('addone','<?=$product['id'];?>','<?=$item['size'];?>')">+
                 </button>
               <?php else: ?>
                 <span class="text-danger">Le max disponile est atteint</span>
               <?php endif;?>
               </td>
               <td><?=$item['size'];?></td>
               <td><?=money($item['quantity'] * $product['prix']); ?></td>
             </tr>
             <?php 
               $i++;
               $item_count += $item['quantity'];
               $sub_total += ($product['prix'] * $item['quantity']);
             }
             $tax = TAXRATE * $sub_total;
             $tax = number_format($tax,2);
             $grand_total = $tax + $sub_total;
             $shipp = '';
             //A ajouter ici les frais de livraison ! (Shipping cost)

             ?>
       </tbody>
      </table>
      <table class="table table-bordered table-condensed text-right">
        <legend>Totaux</legend>
      <thead class="totals-table-header"><th>Total d'éléments</th><th>Sub Total</th><th>Frais de livraison</th><th>T.V.A</th><th>Le grand total</th></thead>
      <tbody>
        <tr>
          <td><?=$item_count;?></td>
          <td><?=money($sub_total);?></td>
          <td><?=money($tax);?></td>
          <td></td>
          <td class="bg-success"><?=money($grand_total);?></td>
        </tr>
      </tbody>
      </table>
<!-- Check Out button -->
<button type="button" class="btn btn-primary pull-right" data-toggle="modal" data-target="#checkoutModal">
  <span class="glyphicon glyphicon-shopping-cart"></span> Continuer >>
</button>

<!-- Modal -->
<div class="modal fade" id="checkoutModal" tabindex="-1" role="dialog" aria-labelledby="checkoutModalLabel">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="checkoutModalLabel">Adresse de livraison</h4>
      </div>
      <div class="modal-body">
        <div class="row">
          <form action="livraison.php" method="post" id="payment-form">
            <span class="bg-danger" id="payment-errors"></span>
            <input type="hidden" name="tax" value="<?=$tax;?>">
            <input type="hidden" name="sub_total" value="<?=$sub_total;?>">
            <input type="hidden" name="grand_total" value="<?=$grand_total;?>">
            <input type="hidden" name="cart_id" value="<?=$cart_id;?>">
            <input type="hidden" name="description" value="<?=$item_count. 'élément'.(($item_count>1)?'s':'').' depuis Workinc Ecommerce.';?>">

            <div id="step1" style="display:block;">
            <div style="text-align: center;">
            <h4><span class="glyphicon glyphicon-home"></span> Remarque Importante :  <br>
                L'opération de livraison ne peut être réalisée que pour les adresses situées dans les pays suivants: 
                Allemand, France, Espagne, Italie, Grand Bretagne, Maroc, Tunisie, Algérie, Libye, Egypte. 
              </h4>
              </div>              
              <div class="form-group col-md-6">
                <label for="name">Nom et prénom:</label>
                <input type="text" name="name" id="name" class="form-control">
              </div>
              <div class="form-group col-md-6">
                <label for="email">E-mail:</label>
                <input type="email" name="email" id="email" class="form-control">
              </div>
              <div class="form-group col-md-6">
                <label for="adresse">Adresse:</label>
                <input type="text" name="adresse" id="adresse" class="form-control" data-stripe="address_line1">
              </div>
              <div class="form-group col-md-6">
                <label for="adresse2">Adresse de parents:</label>
                <input type="text" name="adresse2" id="adresse2" class="form-control" data-stripe="address_line2">
              </div>
              <div class="form-group col-md-6">
                <label for="ville">Ville:</label>
                <input type="text" name="ville" id="ville" class="form-control" data-stripe="address_city">
              </div>
              <div class="form-group col-md-6">
                <label for="region">Région:</label>
                <input type="text" name="region" id="region" class="form-control" data-stripe="address_state">
              </div>
              <div class="form-group col-md-6">
                <label for="code_postal">Code postal:</label>
                <input type="text" name="code_postal" id="code_postal" class="form-control" data-stripe="address_zip">
              </div>
              <div class="form-group col-md-6">
                <label for="pays">Pays:</label>
                <select name="pays" id="pays" class="form-control" data-stripe="address_country">
                  <option value="valeur1" selected>Allemand</option> 
                  <option value="valeur2">France</option>
                  <option value="valeur3">Espagne</option>
                  <option value="valeur4">Italie</option> 
                  <option value="valeur5">Grand Bretagne</option>
                  <option value="valeur6">Maroc</option>
                  <option value="valeur7">Tunisie</option>
                  <option value="valeur8">Algérie</option> 
                  <option value="valeur9">Libye</option>
                  <option value="valeur10">Egypte</option>
                </select>
              </div>              
            </div>
            <div id="step2" style="display:none;">
              <div class="form-group col-md-2">
                <label for="name">Nom sur la carte:</label>
                <input type="text" id="name" class="form-control" data-stripe="name">
              </div>
              <div class="form-group col-md-3">
                <label for="number">Numero de la carte:</label>
                <input type="text" id="number" class="form-control" data-stripe="number">
              </div>
              <div class="form-group col-md-3">
                <label for="cvc">CVC:</label>
                <input type="text" id="cvc" class="form-control" data-stripe="cvc">
              </div>
              <div class="form-group col-md-3">
                <label for="exp-month">Mois d'éxpiration:</label>
                <select id="exp-month" class="form-control" data-stripe="exp-month">
                  <option value=""></option>
                  <?php for($i=1;$i<13;$i++): ?>
                    <option value="<?=$i;?>"><?=$i;?></option>
                  <?php endfor; ?>
                </select>
              </div>
              <div class="form-group col-md-3">
                <label for="exp-year">Année d'expiration:</label>
                <select id="exp-year" class="form-control" data-stripe="exp-year">
                  <option value=""></option>
                  <?php $yar = date("Y"); ?>
                  <?php for($i=0;$i<12;$i++): ?>
                    <option value="<?=$yar+$i;?>"><?=$yar+$i;?></option>
                  <?php endfor; ?> 
                </select>
              </div>
            </div>
          
        </div>
      </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary" onclick="check_address();" id="next_button">Suivant >></button>
        <button type="button" class="btn btn-primary" onclick="back_address();" id="back_button" style="display:none;">
          << Précédent</button>
        <button type="submit" class="btn btn-primary" id="checkout_button" style="display:none;">Continuer >></button>
      </form>
      </div>
    </div>
  </div>
</div>

<?php endif;?>
</div>
</div>
<script>

  function back_address(){
    jQuery('#payment-errors').html("");
    jQuery('#step1').css("display","block");
    jQuery('#step2').css("display","none");
    jQuery('#next_button').css("display","inline-block");
    jQuery('#back_button').css("display","none");
    jQuery('#checkout_button').css("display","none");
    jQuery('#checkoutModalLabel').html("Adresse de livraison");
  }

  function check_address(){
    var data = {
      'name' : jQuery('#name').val(),
      'email' : jQuery('#email').val(),
      'adresse' : jQuery('#adresse').val(),
      'adresse2' : jQuery('#adresse2').val(),
      'ville' : jQuery('#ville').val(),
      'region' : jQuery('#region').val(),
      'code_postal' : jQuery('#code_postal').val(),
      'pays' : jQuery('#pays').val(),
    };
    jQuery.ajax({
      url : '/EcommerceShipping/admin/parsers/check_address.php',
      method : 'POST',
      data : data,
      success : function(data){
        if (data != 'passed'){
          jQuery('#payment-errors').html(data);
        }
        if (data == 'passed'){
          jQuery('#payment-errors').html("");
          jQuery('#step1').css("display","none");
          jQuery('#step2').css("display","block");
          jQuery('#next_button').css("display","none");
          jQuery('#back_button').css("display","inline-block");
          jQuery('#checkout_button').css("display","inline-block");
          jQuery('#checkoutModalLabel').html("Détails de la carte de paiement"); 

        }
      },
      error : function(){
        alert("Echèc! Il y a une erreur.");
      },
    });
  } 

  Stripe.setPublishableKey('<?=STRIPE_PUBLIC;?>');

  function stripeResponseHandler(status, response){
    var $form = $('#payment-form');

  if (response.error){
    $form.find('.payment-errors').text(response.error.message);
    $form.find('.button').text('disabled', false);
  }else{
    var token = response.id;

    $form.append($('<input type="hidden" name="stripeToken"/>').val(token));

    $form.get(0).submit();
  }
};

  jQuery(function($){
    $('#payment-form').submit(function(event){
      var $form = $(this);

      $form.find('button').prop('disabled', true);

      Stripe.card.createToken($form, stripeResponseHandler);
      return false;
    });

  });
    
</script>
<?php include 'includes/footer.php'; ?>﻿