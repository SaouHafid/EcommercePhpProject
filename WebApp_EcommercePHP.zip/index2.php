<!DOCTYPE html>
<html>
<head>
	<title>Workinc Ecommerce Shipping</title>
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/bootstrap.css">
	<link rel="stylesheet" href="css/bootstrap-theme.css">
	<link rel="stylesheet" href="css/bootstrap-theme.min.css">
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
</head>
<body>
 
		<nav class="navbar navbar-inverse">
		  <div class="container">
		    <div class="navbar-header">
		      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
		        <span class="icon-bar"></span>
		        <span class="icon-bar"></span>
		        <span class="icon-bar"></span> 
		      </button>
		      <a class="navbar-brand" href="index2.php">Workinc Ecommerce</a>
		    </div>
		    <div class="collapse navbar-collapse" id="myNavbar">
		      <ul class="nav navbar-nav">
		        <li class="dropdown">
				<a href="#" class="dropdown-toggle" data-toggle="dropdown">Hommes<span class="caret"></span></a>
				<ul class="dropdown-menu" role="menu">
					<li><a href="#">T-Shirts</a></li>
					<li><a href="#">Pantalons</a></li>
					<li><a href="#">Chassures</a></li>
					<li><a href="#">Accessoires</a></li> 
				</ul>
				</li>

		      <ul class="nav navbar-nav navbar-right">
		        <li><a href="#"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
		        <li><a href="#"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
		      </ul>
		      
		      </ul> 
		    </div>
		  </div>
		</nav> 

	<!-- Header -->
	<div id="headerWrapper">
		<div id="back-flower"></div>
		<div id="logotext"></div>
		<div id="for-flower"></div>
	</div>

</body>
</html>