<?php
require_once 'core/init.php';
//require 'C:\xampp\htdocs\EcommerceShipping\panier.php';

\Stripe\Stripe::setApiKey(STRIPE_PRIVATE);

$token = $_POST['stripeToken'];

$name = sanitize($_POST['name']);
$email = sanitize($_POST['email']);
$adresse = sanitize($_POST['adresse']);
$adresse2 = sanitize($_POST['adresse2']);
$ville = sanitize($_POST['ville']);
$region = sanitize($_POST['region']);
$code_pstal = sanitize($_POST['code_pstal']);
$pays = sanitize($_POST['pays']);
$tax = sanitize($_POST['tax']);
$sub_total = sanitize($_POST['sub_total']);
$grand_total = sanitize($_POST['grand_total']);
$cart_id = sanitize($_POST['cart_id']);
$description = sanitize($_POST['description']);
$charge_amount = number_format($grand_total,2) * 100;
$metadata = array(
	"cart_id" => $cart_id,
	"tax"  => $tax,
	$sub_total => $sub_total,
);

try {
	$charge = \Stripe\Charge::create(array(
    "amount" => $charge_amount,
    "currency" => CURRENCY,
    "source" => $token,
    "description" => $description,
    "receipt_email" => $email,
    "metadata" => $metadata)
	);

$db->query("UPDATE panier SET paye = 1 WHERE id= '{$cart_id}'");
$db->query("INSERT INTO transactions(id, charge_id, cart_id, name, email, street, street2, city, state, zip_code, country, sub_total, tax, grand_total, description, txn_type) VALUES ('$charge->id','$cart_id','$name','$email','$adresse','$adresse2','$ville','$region','$code_pstal','$pays','$sub_total','$tax','$grand_total','$description','$charge->object')");

$domain = ($_SERVER['HTTP_HOST'] != 'localhost')? '.'.$_SERVER['HTTP_HOST']:false;
setcookie(CART_COOKIE,'',1,"/",$domain,false);
include 'includes/head.php';
include 'includes/navigation.php';
include 'includes/headerpartiel.php'; 
?>
	<h1 class="text-center text-success">Merci braucoup!</h1>
	<p>Votre carte à été bien chargée <?=money($grand_total);?>. Vous avez reçu un reçu par courrier électronique. vérifiez votre dossier span si ce n'est pas dans votre boîte de réception. De plus, vous pouvez imprimer cette page comme un reçu.</p>
	<p>Votre numéro de reçu est: <strong><?=$cart_id;?></strong></p>
	<p>Votre commande sera livrée vers l'adresse suivante:</p>
	<address>
		<?=$name;?><br>
		<?=$adresse; ?><br>
		<?=(($adresse2 != '')?$adresse2.'<br>':'');?>
		<?=$ville.', '.$region.' '.$code_pstal;?><br>
		<?=$pays;?><br>
	</address>
<?php include 'includes/footer.php';

} catch (\Stripe\Error\Card $e) {
	echo $e;
}
?>